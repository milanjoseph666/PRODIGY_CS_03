
# Password Complexity Checker

This tool checks the strength of a password based on several criteria:
- Minimum length of 8 characters
- At least one uppercase letter
- At least one lowercase letter
- At least one number
- At least one special character

## How to Run

```bash
python password_checker.py
```

Enter your password when prompted, and you'll receive feedback on its strength.
